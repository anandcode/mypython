# -*- coding: utf-8 -*-
"""
Created on Tue Jun  5 12:13:14 2018

@author: anandhamurugan.b
"""

import pandas as pd
import re
import os
import time
import datetime
from GetConfig import GetConfig as GC


#import locale as locale

class GenerateCobTree(object):

    def __init__(self, program):
        self.program_file = program[0] + '.CBL'
        self.program_name = program[0]
        self.program_id = program[1]
        self.lineno = 0
        self.laststno = 0
        self.notfirstpara = False
        self.notfirstsec = False
        self.stmttabl = []
        self.stmtlist =[]
        self.paratabl = []
        self.paralist =[]
        self.seclist=[]
        self.sectabl=[]
        self.startprocess=False
        self.firstpara=True
        self.firstsec=True
        self.secnmstart=0
        self.perfstmt=''
        self.peformstmt=False
        self.prfstno = 0
        self.perftabl = []
        self.currentparasec = ''
        self.currentype=''
        self.trigline=0
        self.perftabl=[]
        self.s_p_id = 0
        self.proc_start_no = 0
        self.userid = 'GDLYMF1'
        num_ts = time.time()
        self.curr_timestamp = datetime.datetime.fromtimestamp(num_ts).strftime('%Y-%m-%d %H:%M:%S')
#        print(locale.getpreferredencoding())

    def open_pgm_file(self):
        pgmopened = open(self.program_file, "r",encoding='ANSI')
        return pgmopened
    
    def parse_line(self,pgmopened):
        pgmline = pgmopened.readline()
        while pgmline:
            self.lineno = self.lineno + 1
            templine = pgmline.ljust(80,' ')
            self.load_stmt_list(pgmline.rstrip('\r\n'))
            pgmline = pgmopened.readline()
            if not (check_if_comment(templine)):
                if self.startprocess:
                    self.parse_paras(templine[0:72]) 
                else:
                    self.procedure_div_stmt(templine[0:72])
        self.append_prev_sec_list()
        self.append_prev_para_list()
                
    def load_stmt_list(self,pgmline):
            pgmline = pgmline.ljust(80,' ')
            self.stmttabl.append([self.program_id,self.lineno,pgmline,self.userid,self.curr_timestamp,self.userid,self.curr_timestamp])
                 
    def print_lst_as_df(self):
        db_load_dir = GC.read_config("config-files","csv-path") 
        
        db_load_dir = os.path.join(db_load_dir,self.program_name)
        os.makedirs(db_load_dir)
        
        df = pd.DataFrame(self.stmttabl,columns=['program-id','pgm_line_no','statement','create_userid','create_timestamp','update_userid','update_timestamp'])
        #print(df)
        stmt_table = db_load_dir + '/' + self.program_name + '_stmt.csv'
        df.to_csv(stmt_table,index=None,line_terminator = '\n')

#        st=open(stmt_flname,"x",encoding='ANSI')
#        st.writelines(df['statement'])

        secparatabl = self.paratabl + self.sectabl
#        def getkey(item):
#           return item[2]    
#        secparatabl.sort(key=getkey)
        pf = pd.DataFrame(secparatabl,columns=['program_id','Type','Name','s_p_id','Startno','Endno','create_userid','create_timestamp','update_userid','update_timestamp'])
        pf.sort_values(by='Startno')
#        print(pf)
        
        self.look_up_s_p_id(secparatabl)
        
        
        split_table = db_load_dir  + '/' + self.program_name + '_split.csv'
        pf.to_csv(split_table, index=None)
#        self.perftabl.sort(key=getkey)
        sf = pd.DataFrame(self.perftabl,columns=['program_id','Parent_node_id','child_node_id','child-type','trigger-line','create_userid','create_timestamp','update_userid','update_timestamp'])
        sf.sort_values(by='trigger-line')
#        print(sf)
        tree_table = db_load_dir + '/' + self.program_name + '_tree.csv'
        sf.to_csv(tree_table, index=None)
        
        
    def get_last_stmt_no(self,pgmline):
        if(("." in pgmline)):
            self.laststno=self.lineno
            
    def check_perform(self,pgmline):
            if (" PERFORM" in pgmline):
                if not (self.perfstmt == ''):
                    self.pattern_match_perform()
                self.peformstmt=True
                self.prfstno = 0
                self.perfstmt = ''
                self.trigline = self.lineno
            if self.peformstmt:
                self.prfstno = self.prfstno + 1
#                self.parse_perform(pgmline[7:72].strip())          
                self.parse_perform(pgmline[7:72].strip())          
        
    def check_if_comment(pgmline):
        if ((pgmline[6] in ('*','/'))):
            return True  
        else:
            return False
    
    def parse_paras(self,pgmline):
#        print('inside process')
        if (pgmline[7].isalnum()):
            if " SECTION." in pgmline:
                self.append_prev_sec_list()
                self.load_sec_list(pgmline)
                self.notfirstsec=True
            else:
                self.append_prev_para_list()
                self.load_para_list(pgmline)
                self.notfirstpara=True
        else:
            self.get_last_stmt_no(pgmline)
            self.check_perform(pgmline)
    
    def load_sec_list(self,pgmline):
        secstmtsplit = pgmline[7:].split(' SECTION.')
        secname = secstmtsplit[0].split()[0]
        cobstmt = secstmtsplit[1].strip()
        self.currentparasec = secname
        self.currentype='S'
        self.get_last_stmt_no(cobstmt)
        if self.firstsec:
            secstartno = self.lineno
            self.firstsec=False
        else:
            secstartno = self.laststno + 1
        
        self.s_p_id = self.s_p_id + 1
        self.secnmstart = self.lineno
        self.seclist.append(self.program_id)
        self.seclist.append('S')
        self.seclist.append(secname)
        self.seclist.append(secstartno)        
        self.get_last_stmt_no(cobstmt)
        
    def append_prev_sec_list(self):
        if self.notfirstsec:
            self.seclist.append(self.laststno)
            self.seclist.append(self.userid)
            self.seclist.append(self.curr_timestamp)
            self.seclist.append(self.userid)
            self.seclist.append(self.curr_timestamp)
#            self.seclist.append(self.userid)
#            self.seclist.append(self.curr_timestamp)
            self.sectabl.append(self.seclist)
            self.seclist=[]
    
    def load_para_list(self,pgmline):
        parastmtsplit = pgmline[7:].split('.',1)
        paraname = parastmtsplit[0]
        self.currentparasec = paraname
        self.currentype='P'
        cobstmt = parastmtsplit[1].strip()
        if self.firstpara:    
            parastartno = self.proc_start_no            
            self.firstpara=False
        else:
            if ((self.laststno+1)>(self.secnmstart+1)):
                parastartno = self.laststno + 1
            else:
                parastartno = self.secnmstart + 1
                
        self.s_p_id = self.s_p_id + 1
        self.paralist.append(self.program_id)
        self.paralist.append('P')
        self.paralist.append(paraname)
        self.paralist.append(self.s_p_id)
        self.paralist.append(parastartno)      
        self.get_last_stmt_no(cobstmt)
        
    
    def append_prev_para_list(self):
        if self.notfirstpara:
            if (self.laststno < self.paralist[3]):
                 self.laststno = self.lineno - 1
            self.paralist.append(self.laststno) 
            self.paralist.append(self.userid)
            self.paralist.append(self.curr_timestamp)
            self.paralist.append(self.userid)
            self.paralist.append(self.curr_timestamp)

            self.paratabl.append(self.paralist)
            self.paralist=[]    
              
    def procedure_div_stmt(self,pgmline):
#        print(pgmline[7:26])
        if pgmline[7:26] == "PROCEDURE DIVISION.":
            self.startprocess=True
            self.proc_start_no = self.lineno + 1
#            print(str(self.startprocess))
            
    def parse_perform(self,line): 
        
        if(" THRU" in line) or (" THROUGH" in line):
            self.perfstmt=self.perfstmt+' '+line
            self.peformstmt=True
            matchObj = re.search(r'(.*)THR(O*)U([G-H]*)(\s+)(\S+)(\s*)',line,re.I)
            if matchObj:
                self.peformstmt=False
        elif(" UNTIL" in line):
            self.perfstmt=self.perfstmt+' '+line
            self.peformstmt=False
        elif(" TIMES" in line):
            self.perfstmt=self.perfstmt+' '+line
            self.peformstmt=False
        elif(" WITH" in line):
            self.perfstmt=self.perfstmt+' '+line
            self.peformstmt=False
        elif(" TEST" in line):
            self.perfstmt=self.perfstmt+' '+line
            self.peformstmt=False
        elif(" VARYING" in line):
            self.perfstmt=self.perfstmt+' '+line
            self.peformstmt=False
        elif(re.match(r'^(\s*)PERFORM$',line,re.I)):
            self.perfstmt= ''
            self.peformstmt=False
        elif(self.prfstno <= 2):
            self.perfstmt=self.perfstmt+' '+line
            self.peformstmt=True
        else:
            self.perfstmt=self.perfstmt+' '+line
            self.peformstmt=False
        
        if not(self.peformstmt):
            self.pattern_match_perform()
        
        return
            
    def pattern_match_perform(self):
        
        perfpara1=''
        perfpara2=''
#        self.perflist = []
        if (self.perfstmt == ''):
            return
        if(re.search(r'(.*)PERFORM(\s+)(\S+)(\s+)TIMES',self.perfstmt,re.I)):
            return
        if(re.search(r'(.*)PERFORM(\s+)WITH',self.perfstmt,re.I)):
            return
        if(re.search(r'(.*)PERFORM(\s+)TEST',self.perfstmt,re.I)):
            return
        if(re.search(r'(.*)PERFORM(\s+)UNTIL',self.perfstmt,re.I)):
            return 
        if(re.search(r'(.*)PERFORM(\s+)VARYING',self.perfstmt,re.I)):
            return 
        if(re.search(r'(.*)PERFORM(\s+)(\S+)(\s+)THR(O*)U([G-H]*)(\s+)(\S+)(\s*)',self.perfstmt,re.I)):
            matchObj=re.search(r'(.*)PERFORM(\s+)(\S+)(\s+)THR(O*)U([G-H]*)(\s+)(\S+)(\s*)',self.perfstmt,re.I)
            if matchObj:
                perfpara1=matchObj.group(3)
                perfpara2=matchObj.group(8).strip('.')
                self.load_para_table(perfpara1)
                self.load_para_table(perfpara2)
        else:
            matchObj=re.search(r'(.*)PERFORM(\s+)(\S+)(\s*)(.*)',self.perfstmt,re.I)
            if matchObj:
                perfpara1=matchObj.group(3).strip('.')
                self.load_para_table(perfpara1)       
                
        self.perfstmt = ''

        return
    
    def load_para_table(self,child_para):
#        self.perflist.append(self.currentparasec)
#        self.perflist.append(self.currentype)
#        self.perflist.append(self.trigline)
#        self.perflist.append(para)
#        self.perflist.append('P')
        self.perftabl.append([self.program_id,self.currentparasec,child_para,'P',self.trigline,self.userid,self.curr_timestamp,self.userid,self.curr_timestamp])
#        self.perflist = []
        return
    
    def look_up_s_p_id(self,secparatabl):
        
        for perform in self.perftabl:
            
            for sec_para in secparatabl:
                
                if (perform[1] == sec_para[2]):
                    perform[1] = sec_para[3]
                
                if (perform[2] == sec_para[2]):
                    perform[2] = sec_para[3]
                    perform[3] = sec_para[1]


def check_if_comment(pgmline):
    return bool(pgmline[6] in ('*','/'))