# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

from InventoryMove import InventoryMove as IM
import GenerateCobTree as GCT
import Preprocess as PP
from  GetConfig import GetConfig as gc
import os        
import pandas as pd
import time
import datetime


try:    
    num_ts = time.time()
    curr_timestamp = datetime.datetime.fromtimestamp(num_ts).strftime('%Y-%m-%d %H:%M:%S')
    print("Batch process Started",curr_timestamp)
    sourcepath = gc.read_config("config-files","source-path")
    targetpath_cbl = gc.read_config("config-files","target-cbl-path") 
    targetpath_cpy = gc.read_config("config-files","target-cpy-path") 
    inventorypath = gc.read_config("config-files","inventory-path")
    csvpath = gc.read_config("config-files","csv-path")
    userid = gc.read_config("Log-files","log-userid")
    timestamp = gc.read_config("Log-files","log-timestamp")


    cbl_files = IM.filter_source_files('CBL',sourcepath)
    os.makedirs(targetpath_cbl)
    IM.shutil_source_files(cbl_files,sourcepath,targetpath_cbl)
    
    cpy_files = IM.filter_source_files('CPY',sourcepath)
    os.makedirs(targetpath_cpy)
    IM.shutil_source_files(cpy_files,sourcepath,targetpath_cpy)
    
#    inv.copy_files_to_target('CBL')
#    inv.copy_files_to_target('CPY')
#    cbl_dir = inv.get_cbl_dir()
#    inv.set_cbl_dir_as_path(cbl_dir)
#    print(os.curdir)
#    cbl_files = inv.list_cbl_dir()
#    print(cbl_files)
    
    os.chdir(targetpath_cbl)
    prp = PP.Preprocess(cbl_files)
    prp.process_cbl_files()
    mnemonic_mapper = os.path.join(csvpath,"pgm_mnemonic_mapper.csv")
    pgm_df = pd.read_csv(mnemonic_mapper)
    pgm_list = pgm_df.values.tolist()
    os.chdir(inventorypath)
    for pgm in pgm_list:
        ct = GCT.GenerateCobTree(pgm)
        pgmopened = ct.open_pgm_file()
        ct.parse_line(pgmopened)
        ct.print_lst_as_df()
        pgmopened.close()
           

#except TypeError as errormsg:
#    print(errormsg)
#except IndexError as e:
#    print("IndexError", e)
#    
#except BaseException as errmsg:
#    print("BaseException", errmsg)   
#else:
#    print("parsing successful no exception")
        
finally:
    num_ts = time.time()
    curr_timestamp = datetime.datetime.fromtimestamp(num_ts).strftime('%Y-%m-%d %H:%M:%S')
    print("parsing completed",curr_timestamp)