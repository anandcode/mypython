# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""          

import json

class GetConfig:

    def read_config(field_type,field_name):
#        try:      
        with open('C:/Users/eluma/Documents/Python Scripts/Config.json') as json_data:
            config = json.load(json_data)
            json_data.close()
            return config[field_type][field_name]
        
#        except ValueError as e:
#                print ("JSON object issue: %s") % e
                
          
#    def get_src_path(config):
#            return config["config-files"]["source-path"]
# 
#    def get_target_path(config):
#            return config["config-files"]["target-path"]
#        
#    def get_inv_path(config):
#            return config["config-files"]["inventory-path"]
#        
#    def get_csv_path(config):
#            return config["config-files"]["csv-path"]