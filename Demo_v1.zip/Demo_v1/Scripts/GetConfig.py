# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""          

import json

class GetConfig:

    def read_config(field_type,field_name):
#        try:      
        with open('C:/Users/eluma/Documents/Python Scripts/Demo/Config.json') as json_data:
            config = json.load(json_data)
            json_data.close()
            return config[field_type][field_name]
        
#        except ValueError as e:
#                print ("JSON object issue: %s") % e