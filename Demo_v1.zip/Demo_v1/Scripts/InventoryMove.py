# -*- coding: utf-8 -*-
"""
Created on Mon Jul 30 14:24:42 2018

@author: anandhamurugan.b
"""

import os
import re
import shutil

class InventoryMove:

    def filter_source_files(src_extn,source_dir):

        ext = src_extn
        evalstring = "(.*)." + ext + "$"
        cbl_regex = re.compile(evalstring,re.I)
        list_filenames = os.listdir(source_dir)
        list_cbl_files = list(filter(cbl_regex.search, list_filenames))
        return list_cbl_files
    
    def shutil_source_files(src_files_list,src_dir,dest_dir):
        
        for src_file in src_files_list:
            src_file = src_file.upper()
            src_path = os.path.join(src_dir,src_file)
            dest_path = os.path.join(dest_dir,src_file)
            shutil.copy(src_path,dest_path)