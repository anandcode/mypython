# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""          
import json
import os

class GetConfig():

    def read_config(field_type,field_name):
        try:
            with open('C:/Users/eluma/Documents/Python Scripts/Demo_v1/Scripts/Config.json') as json_data:
                config = json.load(json_data)
                json_data.close()   
                return config[field_type][field_name]
            
#        except ValueError as e:
#                print ("JSON object issue: %s") % e
        finally:
            pass
    
    def create_directories(config_file_path):
        
        try:      
            with open(config_file_path) as config_file:
                config = json.load(config_file)
                config_file.close()
            os.makedirs(config["config-files"]["target-cbl-path"])
            os.makedirs(config["config-files"]["target-cpy-path"])
            os.makedirs(config["config-files"]["inventory-path"])
            os.makedirs(config["config-files"]["csv-path"])
            os.makedirs(config["report-files"]["report-path"])
            missing_file_name = config["report-files"]["missing-report"]
            print(missing_file_name)
            missing_report_csv = open(missing_file_name,'x',encoding='ANSI')
            missing_report_csv.close()
            
            status_file_name = config["report-files"]["status-report"]
            print(status_file_name)
            status_report_csv = open(status_file_name,'x',encoding='ANSI')
            status_report_csv.close()
            
#        except ValueError as e:
#                print ("JSON object issue: %s") % e    
#        except BaseException as e:
#                print ("Exception occured: %s") % e
        finally:
            print("created folders")
    
    