# -*- coding: utf-8 -*-
"""
Created on Mon Jun 25 16:05:24 2018
@author: anandhamurugan.b
"""
import os.path
import re
import pandas as pd

class Preprocess():

    def __init__(self, cbl_files):
        self.list_cbl_files = cbl_files
        self.op_stmt_list=[]
        self.pgm_id = 0
        self.pgm_status_tabl=[]
        self.comp_status_list=[]
        self.missing_list=[]
    
    def __delete__(self):
        print("preporcess object destroyed::", id(self))
        
    def process_cbl_files (self,gc):
        pgm_id = 0
        for cbl_pgm in self.list_cbl_files:
            self.op_stmt_list = []
            pgm_id = pgm_id + 1
            self.comp_status_list.append(pgm_id)
            self.read_cbl_file(cbl_pgm, gc)
            self.pgm_status_tabl.append(self.comp_status_list)
            self.comp_status_list=[]
        self.write_reports(gc)
        print(self.pgm_status_tabl)
        return
            
    def read_cbl_file(self,cbl_pgm, gc):
        cob_prog = False
        stmt_no = 0
        copybook_cnt = 0
        missing_copybook_cnt = 0
        targetpath_cpy = gc.get_file_path("config-files","target-cpy-path") 
        stmt_list = read_src_file(cbl_pgm)
        pgm_name = cbl_pgm.split(".")[0]
        self.comp_status_list.append(pgm_name)
        self.comp_status_list.append('COBOL')
        self.comp_status_list.append(len(stmt_list))
        pgm_status = 'VERIFIED'
        comments = 'SUCCESSFUL' 
    
        for stmt in stmt_list:
            stmt_no = stmt_no + 1
            
            if (check_if_comment(stmt.ljust(80,' '))):
                self.preprocess(stmt)
                continue
            
            if (" COPY " in stmt.upper()):
                copybook = get_copybook(stmt[0:72].upper().rstrip())
                cpy_file = copybook + ".CPY"
                cpy_file_name = os.path.join(targetpath_cpy, cpy_file)
                copybook_cnt = copybook_cnt + 1
                if(os.path.exists(cpy_file_name)):         
                    stmt = stmt[0:6] + '*' + stmt[7:]
                    self.preprocess(stmt)
                    cpy_stmt_list = read_src_file(cpy_file_name)
                    self.op_stmt_list.extend(cpy_stmt_list)                    
                    continue
                else:
                    missing_copybook_cnt = missing_copybook_cnt + 1
                    pgm_status = "MISSING"
                    comments = "COPYBOOK(s)/SUBROUTINE(s) MISSING" 
                    self.missing_list.append(['COBOL',pgm_name,'COPYBOOK',copybook])
                                   
            if not(cob_prog):
                cob_prog = check_if_cbl_pgm(stmt.ljust(80,' ').upper())
                
            self.preprocess(stmt)
            
        if not(cob_prog):
            if pgm_status == "MISSING":
                self.missing_list.pop()
            pgm_status = "VERIFICATION FAILED"
            comments = 'NOT A VALID COBOL - ID division missing'
            self.comp_status_list.append(0)
            self.comp_status_list.append(0)
            self.comp_status_list.append(0)
            self.comp_status_list.append(pgm_status)
            self.comp_status_list.append(comments)
            print("No ID DIVISION - skipped file",cbl_pgm)
            return
        
        self.write_expanded_pgm(cbl_pgm, gc)
        self.comp_status_list.append(copybook_cnt)
        self.comp_status_list.append(missing_copybook_cnt)
        self.comp_status_list.append(pgm_status)
        self.comp_status_list.append(comments)
        return
        
#    def load_mnemonic_mapper(self,pgm_name, gc):
#        self.pgm_id = self.pgm_id + 1
#        userid = gc.get_file_path("Log-files","log-userid")
#        timestamp = gc.get_file_path("Log-files","log-timestamp")
#        self.pgm_list.append([pgm_name,self.pgm_id,userid,timestamp,userid,timestamp])
#        print("write sucess",pgm_name)
#        return
                
    def preprocess(self,stmt):
        self.op_stmt_list.append(stmt)
        
    def write_expanded_pgm(self,cbl_pgm, gc):
        inventorypath = gc.get_file_path("config-files","inventory-path")
        expandfile = os.path.join(inventorypath, cbl_pgm)
        cob_ex_file = open(expandfile,'x',encoding='ANSI')
        self.comp_status_list.append(len(self.op_stmt_list))
        cob_ex_file.writelines(self.op_stmt_list)
        cob_ex_file.close()
    
    def write_reports(self, gc):
        mf = pd.DataFrame(self.missing_list,columns=['component_type','component_name','missing_type','missing_component_name'])
        missing_report = gc.get_file_path("report-files","missing-report") 
        mf.to_csv(missing_report,mode='a',index=None)

#        sf = pd.DataFrame(self.comp_status_tabl,columns=['component_type','component_name','original_loc','expanded_loc','tot_dependencies','missing_dependencies','status','comments'])
#        status_report = gc.get_file_path("report-files","status-report") 
#        sf.to_csv(status_report,mode='a',index=None)
      
def read_src_file(file_name):
    src_file = open(file_name,'r',encoding='ANSI')
    stmt_list = src_file.readlines()
    src_file.close()
    return stmt_list
       
def check_if_comment(stmt):
    return bool (stmt[6] in ('*','/'))
       
def get_copybook(stmt):
    matchObj = re.search(r'(.*)(\s+)COPY(\s+)(\S+)(\s*)(.*)',stmt,re.I)
    copybook = matchObj.group(4)
    copybook = copybook.strip('.')
    return copybook
        
def check_if_cbl_pgm(stmt):
    if stmt[7:31] == ("IDENTIFICATION DIVISION."):
        return True
    elif stmt[7:19] == ("ID DIVISION."):
        return True
    else:
        return False