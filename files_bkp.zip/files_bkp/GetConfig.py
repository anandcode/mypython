# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""          
import json
import os

class GetConfig():
    
    def __init__(self, config_file_path):
        try:
            with open(config_file_path) as config_file:
                self.config = json.load(config_file)
                config_file.close()
        except ValueError as e:
            print ("JSON object issue: %s") % e
           
    def get_file_path(self,field_type,field_name):
        try: 
            return self.config[field_type][field_name]
        except ValueError as e:
                print ("JSON object issue: %s") % e    
        except BaseException as e:
                print ("Exception occured: %s") % e

                
    def create_directories(self):
        try:      
            os.makedirs(self.config["config-files"]["target-cbl-path"])
            os.makedirs(self.config["config-files"]["target-cpy-path"])
            os.makedirs(self.config["config-files"]["inventory-path"])
            os.makedirs(self.config["config-files"]["csv-path"])
            os.makedirs(self.config["report-files"]["report-path"])
            missing_file_name = self.config["report-files"]["missing-report"]
            print(missing_file_name)
            missing_report_csv = open(missing_file_name,'x',encoding='ANSI')
            missing_report_csv.close()
            
            status_file_name = self.config["report-files"]["status-report"]
            print(status_file_name)
            status_report_csv = open(status_file_name,'x',encoding='ANSI')
            status_report_csv.close()
            
#        except ValueError as e:
#                print ("JSON object issue: %s") % e    
#        except BaseException as e:
#                print ("Exception occured: %s") % e
        finally:
            print("created folders")
    
    