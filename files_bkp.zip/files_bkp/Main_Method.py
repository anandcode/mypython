# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
from InventoryMove import InventoryMove as IM
import GenerateCobTree as GCT
import Preprocess as PP
import GetConfig as gc
import os        
import time
import datetime
#import sys

try:    
    num_ts = time.time()
    curr_timestamp = datetime.datetime.fromtimestamp(num_ts).strftime('%Y-%m-%d %H:%M:%S')
    print("Batch process Started",curr_timestamp)
#    config_file_path = sys.argv[1]
    config_file_path = "C:/Users/eluma/Documents/Python Scripts/Demo_v1/Scripts/Config.json"
    if os.path.exists(config_file_path): 
        pass
    else:
        raise FileNotFoundError("Config_file_path not found")
    gcg = gc.GetConfig(config_file_path)
    gcg.create_directories()
    sourcepath = gcg.get_file_path("config-files","source-path")
    targetpath_cbl = gcg.get_file_path("config-files","target-cbl-path") 
    targetpath_cpy = gcg.get_file_path("config-files","target-cpy-path") 
    inventorypath = gcg.get_file_path("config-files","inventory-path")
    csvpath = gcg.get_file_path("config-files","csv-path")
    userid = gcg.get_file_path("Log-files","log-userid")
    timestamp = gcg.get_file_path("Log-files","log-timestamp")

    cbl_files = IM.filter_source_files('CBL',sourcepath)
    IM.shutil_source_files(cbl_files,sourcepath,targetpath_cbl)
    cpy_files = IM.filter_source_files('CPY',sourcepath)
    IM.shutil_source_files(cpy_files,sourcepath,targetpath_cpy)     
    
    os.chdir(targetpath_cbl)
    prp = PP.Preprocess(cbl_files)
    prp.process_cbl_files(gcg)
    
    os.chdir(inventorypath)
    ct = GCT.GenerateCobTree(prp.pgm_status_tabl, gcg)
    ct.write_pgm_mnemonic()
    ct.write_reports()
        
#except BaseException as errmsg:
#    print("BaseException", errmsg)   
#    
#else:
#    print("parsing successful no exception")
        
finally:
    num_ts = time.time()
    curr_timestamp = datetime.datetime.fromtimestamp(num_ts).strftime('%Y-%m-%d %H:%M:%S')
    print("parsing completed",curr_timestamp)