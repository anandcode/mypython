# -*- coding: utf-8 -*-
"""
Created on Tue Jun  5 12:13:14 2018

@author: anandhamurugan.b
"""

import os
import time
import datetime
import pandas as pd
import re
#from GetConfig import GetConfig as GC

class GenerateCobTree():

    def __init__(self, pgm_status_list, gcg):
        self.program_list = pgm_status_list
        self.missing_list = []
        self.gc = gcg
        self.program_index = 0
        for program in self.program_list: 
            if (program[7] == "VERIFIED" or program[7] == "MISSING"):
                self.process_pgm(program)
                self.open_pgm_file()
                pgmopened = self.open_pgm_file()
                self.parse_line(pgmopened)
                self.print_lst_as_df()
                pgmopened.close()
            self.program_index = self.program_index + 1
       
    def process_pgm(self,program):
        self.program_file = program[1] + '.CBL'
        self.program_name = program[1]
        self.program_id = program[0]
        self.lineno = 0
        self.laststno = 0
        self.notfirstpara = False
        self.notfirstsec = False
        self.stmttabl = []
        self.stmtlist =[]
        self.paratabl = []
        self.paralist =[]
        self.seclist=[]
        self.sectabl=[]
        self.startprocess=False
        self.firstpara=True
        self.firstsec=True
        self.secnmstart=0
        self.perfstmt=''
        self.peformstmt=False
        self.prfstno = 0
        self.perftabl = []
        self.currentparasec = ''
        self.currentype=''
        self.trigline=0
        self.perftabl=[]
        self.s_p_id = 0
        self.proc_start_no = 0
        self.userid = 'GDLYMF1'
        num_ts = time.time()
        self.curr_timestamp = datetime.datetime.fromtimestamp(num_ts).strftime('%Y-%m-%d %H:%M:%S')

    def open_pgm_file(self):
        pgmopened = open(self.program_file, "r",encoding='ANSI')
        return pgmopened
    
    def parse_line(self,pgmopened):
        pgmline = pgmopened.readline()
        while pgmline:
            self.lineno = self.lineno + 1
            templine = pgmline.ljust(80,' ')
            self.load_stmt_list(pgmline.rstrip('\r\n'))
            pgmline = pgmopened.readline()
            if not (check_if_comment(templine)):
                if self.startprocess:
                    self.parse_paras(templine[0:72]) 
                else:
                    self.procedure_div_stmt(templine[0:72])
        self.append_prev_sec_list()
        self.append_prev_para_list()
                
    def load_stmt_list(self,pgmline):
            pgmline = pgmline.ljust(80,' ')
            self.stmttabl.append([self.program_id,self.lineno,pgmline,self.userid,self.curr_timestamp,self.userid,self.curr_timestamp])
                 
    def print_lst_as_df(self):
        db_load_dir = self.gc.get_file_path("config-files","csv-path") 
        
        db_load_dir = os.path.join(db_load_dir,self.program_name)
        os.makedirs(db_load_dir)
        
        df = pd.DataFrame(self.stmttabl,columns=['program-id','pgm_line_no','statement','create_userid','create_timestamp','update_userid','update_timestamp'])

        stmt_table = os.path.join(db_load_dir,(self.program_name + '_stmt.csv'))
        df.to_csv(stmt_table,index=None,line_terminator = '\n')

#        st=open(stmt_flname,"x",encoding='ANSI')
#        st.writelines(df['statement'])

        secparatabl = self.paratabl + self.sectabl
#        def getkey(item):
#           return item[2]    
#        secparatabl.sort(key=getkey)
        pf = pd.DataFrame(secparatabl,columns=['program_id','Type','Name','s_p_id','Startno','Endno','create_userid','create_timestamp','update_userid','update_timestamp'])
        pf.sort_values(by='Startno')
#        print(pf)
        
        self.look_up_s_p_id(secparatabl)
        
        split_table = os.path.join(db_load_dir, (self.program_name + '_split.csv'))
        pf.to_csv(split_table, index=None)
#        self.perftabl.sort(key=getkey)
        sf = pd.DataFrame(self.perftabl,columns=['program_id','Parent_node_id','child_node_id','child-type','trigger-line','create_userid','create_timestamp','update_userid','update_timestamp'])
        sf.sort_values(by='trigger-line')
#        print(sf)
        tree_table = os.path.join(db_load_dir,(self.program_name + '_tree.csv'))
        sf.to_csv(tree_table, index=None)
        
        
    def get_last_stmt_no(self,pgmline):
        if(("." in pgmline)):
            self.laststno=self.lineno
            
    def check_perform(self,pgmline):
            if (" PERFORM" in pgmline.upper()):
                if not (self.perfstmt == ''):
                    self.pattern_match_perform()
                self.peformstmt=True
                self.prfstno = 0
                self.perfstmt = ''
                self.trigline = self.lineno
            if self.peformstmt:
                self.prfstno = self.prfstno + 1
#                self.parse_perform(pgmline[7:72].strip())          
                self.parse_perform(pgmline[7:72].strip())     
                
    def check_GOTO(self,pgmline):
            if (" GOTO" in pgmline.upper()):
                para_sec_name = get_verb_label(pgmline,'GOTO')
                if para_sec_name == None:
                    print("GOTO VERB COULD NOT BE PARSED",pgmline)
                    self.program_list[self.program_index][7] = 'VERIFICATION FAILED'
                    self.program_list[self.program_index][8] = 'GOTO VERB COULD NOT BE RESOLVED'
                    return
                self.load_cob_tree(para_sec_name,'P')
            elif("GO TO" in pgmline.upper()):
                para_sec_name = get_verb_label(pgmline,'GO TO')
                if para_sec_name == None:
                    print("GO TO VERB COULD NOT BE PARSED",pgmline)
                    self.program_list[self.program_index][7] = 'VERIFICATION FAILED'
                    self.program_list[self.program_index][8] = 'GO TO VERB COULD NOT BE RESOLVED'
                    return
                self.load_cob_tree(para_sec_name,'P')
                
    def check_call(self,pgmline):
        if (" CALL " in pgmline.upper()):
            called_pgm = get_verb_label(pgmline[7:72].upper().rstrip(),'CALL')
            if called_pgm == None:
                print("CALL VERB COULD NOT BE PARSED",pgmline)
                self.program_list[self.program_index][7] = 'VERIFICATION FAILED'
                self.program_list[self.program_index][8] = 'CALL VERB COULD NOT BE RESOLVED'
                return
            if ("'" in called_pgm):
                called_pgm = called_pgm.strip("'")
                self.load_cob_tree(called_pgm,'C')
                self.program_list[self.program_index][5] = self.program_list[self.program_index][5] + 1
            elif('"' in called_pgm):
                called_pgm = called_pgm.strip('"')
                self.load_cob_tree(called_pgm,'C')
                self.program_list[self.program_index][5] = self.program_list[self.program_index][5] + 1
            else:
                self.load_cob_tree(called_pgm,'D')
                self.program_list[self.program_index][5] = self.program_list[self.program_index][5] + 1
    
    def parse_paras(self,pgmline):
#        print('inside process')
        if (pgmline[7].isalnum()):
            if " SECTION." in pgmline:
                self.append_prev_sec_list()
                self.load_sec_list(pgmline)
                self.notfirstsec=True
            else:
                self.append_prev_para_list()
                self.load_para_list(pgmline)
                self.notfirstpara=True
        else:
            self.get_last_stmt_no(pgmline)
            self.check_perform(pgmline)
            self.check_call(pgmline)
            self.check_GOTO(pgmline)
    
    def load_sec_list(self,pgmline):
        secstmtsplit = pgmline[7:].split(' SECTION.')
        secname = secstmtsplit[0].rstrip()
        if len(secstmtsplit) > 1:
            cobstmt = secstmtsplit[1].strip()
            self.get_last_stmt_no(cobstmt)
        self.currentparasec = secname
        self.currentype='S'
        if self.firstsec:
            secstartno = self.lineno
            self.firstsec=False
        else:
            secstartno = self.laststno + 1
        
        self.s_p_id = self.s_p_id + 1
        self.secnmstart = self.lineno
        self.seclist.append(self.program_id)
        self.seclist.append('S')
        self.seclist.append(secname)
        self.seclist.append(secstartno)        
        self.get_last_stmt_no(cobstmt)
        
    def append_prev_sec_list(self):
        if self.notfirstsec:
            self.seclist.append(self.laststno)
            self.seclist.append(self.userid)
            self.seclist.append(self.curr_timestamp)
            self.seclist.append(self.userid)
            self.seclist.append(self.curr_timestamp)
#            self.seclist.append(self.userid)
#            self.seclist.append(self.curr_timestamp)
            self.sectabl.append(self.seclist)
            self.seclist=[]
    
    def load_para_list(self,pgmline):
        parastmtsplit = pgmline[7:].split('.',1)
        paraname = parastmtsplit[0]
        self.currentparasec = paraname
        self.currentype='P'

        if self.firstpara:    
            parastartno = self.proc_start_no            
            self.firstpara=False
        else:
            if ((self.laststno+1)>(self.secnmstart+1)):
                parastartno = self.laststno + 1
            else:
                parastartno = self.secnmstart + 1
                
        self.s_p_id = self.s_p_id + 1
        self.paralist.append(self.program_id)
        self.paralist.append('P')
        self.paralist.append(paraname)
        self.paralist.append(self.s_p_id)
        self.paralist.append(parastartno)
        if len(parastmtsplit) > 1:
            cobstmt = parastmtsplit[1].strip()
            self.get_last_stmt_no(cobstmt)
          
    def append_prev_para_list(self):
        if self.notfirstpara:
            if (self.laststno < self.paralist[3]):
                 self.laststno = self.lineno - 1
            self.paralist.append(self.laststno) 
            self.paralist.append(self.userid)
            self.paralist.append(self.curr_timestamp)
            self.paralist.append(self.userid)
            self.paralist.append(self.curr_timestamp)

            self.paratabl.append(self.paralist)
            self.paralist=[]    
              
    def procedure_div_stmt(self,pgmline):
#        print(pgmline[7:26])
        if pgmline[7:26] == "PROCEDURE DIVISION.":
            self.startprocess=True
            self.proc_start_no = self.lineno + 1
#            print(str(self.startprocess))
            
    def parse_perform(self,line): 
        
        if(" THRU" in line) or (" THROUGH" in line):
            self.perfstmt=self.perfstmt+' '+line
            self.peformstmt=True
            matchObj = re.search(r'(.*)THR(O*)U([G-H]*)(\s+)(\S+)(\s*)',line,re.I)
            if matchObj:
                self.peformstmt=False
        elif(" UNTIL" in line):
            self.perfstmt=self.perfstmt+' '+line
            self.peformstmt=False
        elif(" TIMES" in line):
            self.perfstmt=self.perfstmt+' '+line
            self.peformstmt=False
        elif(" WITH" in line):
            self.perfstmt=self.perfstmt+' '+line
            self.peformstmt=False
        elif(" TEST" in line):
            self.perfstmt=self.perfstmt+' '+line
            self.peformstmt=False
        elif(" VARYING" in line):
            self.perfstmt=self.perfstmt+' '+line
            self.peformstmt=False
        elif(re.match(r'^(\s*)PERFORM$',line,re.I)):
            self.perfstmt= ''
            self.peformstmt=False
        elif(self.prfstno <= 2):
            self.perfstmt=self.perfstmt+' '+line
            self.peformstmt=True
        else:
            self.perfstmt=self.perfstmt+' '+line
            self.peformstmt=False
        
        if not(self.peformstmt):
            self.pattern_match_perform()
        
        return
            
    def pattern_match_perform(self):
        
        perfpara1=''
        perfpara2=''
        if (self.perfstmt == ''):
            return
        if(re.search(r'(.*)PERFORM(\s+)(\S+)(\s+)TIMES',self.perfstmt,re.I)):
            return
        if(re.search(r'(.*)PERFORM(\s+)WITH',self.perfstmt,re.I)):
            return
        if(re.search(r'(.*)PERFORM(\s+)TEST',self.perfstmt,re.I)):
            return
        if(re.search(r'(.*)PERFORM(\s+)UNTIL',self.perfstmt,re.I)):
            return 
        if(re.search(r'(.*)PERFORM(\s+)VARYING',self.perfstmt,re.I)):
            return 
        if(re.search(r'(.*)PERFORM(\s+)(\S+)(\s+)THR(O*)U([G-H]*)(\s+)(\S+)(\s*)',self.perfstmt,re.I)):
            matchObj=re.search(r'(.*)PERFORM(\s+)(\S+)(\s+)THR(O*)U([G-H]*)(\s+)(\S+)(\s*)',self.perfstmt,re.I)
            if matchObj:
                perfpara1=matchObj.group(3)
                perfpara2=matchObj.group(8).strip('.')
                self.load_cob_tree(perfpara1,'P')
                self.load_cob_tree(perfpara2,'P')
        else:
            matchObj=re.search(r'(.*)PERFORM(\s+)(\S+)(\s*)(.*)',self.perfstmt,re.I)
            if matchObj:
                perfpara1=matchObj.group(3).strip('.')
                self.load_cob_tree(perfpara1,'P')       
                
        self.perfstmt = ''
        return
    
    def load_cob_tree(self,child_name,child_type):
        self.perftabl.append([self.program_id,self.currentparasec,child_name,child_type,self.trigline,self.userid,self.curr_timestamp,self.userid,self.curr_timestamp])
        return
    
    def look_up_s_p_id(self,secparatabl):       
        for perform in self.perftabl:            
            for sec_para in secparatabl:    
                if (perform[1] == sec_para[2]):
                    perform[1] = sec_para[3]
                if (perform[3] == 'P'): 
                    if (perform[2] == sec_para[2]):
                        perform[2] = sec_para[3]
                        perform[3] = sec_para[1]                            
                        
            if (perform[3] == 'D'):
                dynamic_pgm = self.find_dynamic_pgm(perform[2])
                if dynamic_pgm == None:
                    pass
                else:
                    perform[2] = dynamic_pgm
                    perform[3] = 'C'
            
            if (perform[3] == 'C'):
                child_pgm_id = self.get_pgm_mnemonic_id(perform[2])
                if (child_pgm_id == 0):
                    perform[3] = 'D'
                else:
                    perform[2] = child_pgm_id
                    
            if (perform[3] == 'D'):
                self.add_missing_subroutine(perform[2])
                                      
    def find_dynamic_pgm(self,called_pgm_var):
        dynamic_stmt = ''
        continue_stmt = False
        contiune_lookup = True
        i = 0
        while((i <= len(self.stmttabl)) and (contiune_lookup == True)):
                if (called_pgm_var in str(self.stmttabl[i][2])) or (continue_stmt == True):
                    dynamic_var_stmt = self.stmttabl[i][2]
                    dynamic_var_stmt = dynamic_var_stmt[7:72].rstrip()
                    if dynamic_var_stmt.endswith('.'):
                        dynamic_stmt = dynamic_stmt + dynamic_var_stmt.upper()
                        continue_stmt = False
                        contiune_lookup = False
                    else:
                        dynamic_stmt = dynamic_stmt + dynamic_var_stmt.upper()
                        continue_stmt = True
                i = i + 1  
        
        if ("VALUE" in dynamic_stmt):
            if ("'" in dynamic_stmt):
                regex_squote1 = "(.*)(\s+)" + called_pgm_var + "(\s+)(.*)value(\s+)([\']+)" 
                regex_squote2 = "(\S+)([\']+)(.*)" 
                regex_string = regex_squote1 + regex_squote2    
            else:
                regex_dquote1 = "(.*)(\s+)" + called_pgm_var + "(\s+)(.*)value(\s+)([\"]+)" 
                regex_dquote2 = "(\S+)([\"]+)(.*)" 
                regex_string = regex_dquote1 + regex_dquote2
            regex = re.compile(regex_string,re.I|re.M)
            matchObj = re.search(regex,dynamic_stmt)
            if matchObj:
                return(matchObj.group(7))
            else:
                print("Dynamic program can not resolved")
                return None
        else:
            print("Dynamic program can not resolved")
            return None

    def get_pgm_mnemonic_id(self,program):
        pgm_id_found = False
        for program_id in self.program_list:
            if program_id[0] == program:
                print(program_id)
                pgm_id_found = True
                pgm_id = program_id[1]     
        if pgm_id_found:
            return pgm_id
        else:
            return 0
            
    def write_pgm_mnemonic(self):
        pass
#        df = pd.DataFrame(self.program_list,columns=['program-name','pgm_id','create_userid','create_timestamp','update_userid','update_timestamp'])
#        csvpath = self.gc.get_file_path("config-files","csv-path") 
#        pgm_mapper = os.path.join(csvpath, 'pgm_mnemonic_mapper.csv')
#        df.to_csv(pgm_mapper,index=None)
    
    def add_missing_subroutine(self,missing_pgm):
        self.program_list[self.program_index][6] = self.program_list[self.program_index][6] + 1
        if self.program_list[self.program_index][7] == "VERIFIED":
           self.program_list[self.program_index][7] = "MISSING" 
           self.program_list[self.program_index][7] = "COPYBOOK(s)/SUBROUTINE(s) MISSING"         
        self.missing_list.append(['COBOL',self.program_name,'subroutine',missing_pgm])
        
    def write_reports(self):       
        mf = pd.DataFrame(self.missing_list,columns=['component_type','component_name','missing_type','missing_component_name'])
        missing_report = self.gc.get_file_path("report-files","missing-report") 
        mf.to_csv(missing_report,mode='a',index=None,header=False)
        
        stf = pd.DataFrame(self.program_list,columns=['component_id','component_name','component_type','original_loc','expanded_loc','tot_dependencies','missing_dependencies','status','comments'])
        status_report = self.gc.get_file_path("report-files","status-report") 
        stf.to_csv(status_report,mode='a',index=None)


def check_if_comment(pgmline):
    return bool(pgmline[6] in ('*','/'))

def get_verb_label(stmt,verb):
    regex_string = '(.*)(\s+)' + verb + '(\s+)(\S+)(\s*)(.*)'
    regex = re.compile(regex_string,re.I)
    matchObj = re.search(regex,stmt)
    if matchObj.group(4):
        called_pgm = matchObj.group(4)
        called_pgm = called_pgm.strip('.')
        return called_pgm
    else:
        return None
    
#def get_goto_para(stmt):
#    matchObj = re.search(r'(.*)(\s+)GOTO(\s+)(\S+)(\s*)(.*)',stmt,re.I)
#    if matchObj.group(4):
#        para_sec_name = matchObj.group(4)
#        para_sec_name = para_sec_name.strip('.')
#        return para_sec_name
#    else:
#        return None
#
#def get_go_to_para(stmt):
#    matchObj = re.search(r'(.*)(\s+)GO TO(\s+)(\S+)(\s*)(.*)',stmt,re.I)
#    if matchObj.group(4):
#        para_sec_name = matchObj.group(4)
#        para_sec_name = para_sec_name.strip('.')
#        return para_sec_name
#    else: 
#        return None

